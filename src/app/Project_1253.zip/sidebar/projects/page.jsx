"use client";
import { useState, useEffect } from "react";
import axios from "axios";

export default function AdminProjects() {
  const [projects, setProjects] = useState([]);
  const [newProject, setNewProject] = useState({
    name: "",
    status: "",
    budget: "",
    deadline: "",
  });

  useEffect(() => {
    // Fetch projects from the API
    const fetchProjects = async () => {
      try {
        const response = await axios.get("/api/projects");
        setProjects(response.data);
      } catch (error) {
        console.error("Error fetching projects:", error);
      }
    };

    fetchProjects();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewProject((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAddProject = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("/api/projects", newProject);
      setProjects((prev) => [...prev, response.data]);
      setNewProject({ name: "", status: "", budget: "", deadline: "" });
    } catch (error) {
      console.error("Error adding project:", error);
    }
  };

  const handleUpdateProject = async (id, updatedProject) => {
    try {
      const response = await axios.put(`/api/projects/${id}`, updatedProject);
      setProjects((prev) =>
        prev.map((project) => (project.id === id ? response.data : project))
      );
    } catch (error) {
      console.error("Error updating project:", error);
    }
  };

  const handleDeleteProject = async (id) => {
    try {
      await axios.delete(`/api/projects/${id}`);
      setProjects((prev) => prev.filter((project) => project.id !== id));
    } catch (error) {
      console.error("Error deleting project:", error);
    }
  };

  return (
    <div className="container mx-auto p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-6 text-center">Admin Projects</h1>

      <div className="bg-white p-6 shadow-lg rounded-lg mb-6">
        <h2 className="text-2xl font-bold mb-4">Add New Project</h2>
        <form onSubmit={handleAddProject}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="text"
              name="name"
              placeholder="Project Name"
              value={newProject.name}
              onChange={handleInputChange}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
            <input
              type="text"
              name="status"
              placeholder="Status"
              value={newProject.status}
              onChange={handleInputChange}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
            <input
              type="number"
              name="budget"
              placeholder="Budget"
              value={newProject.budget}
              onChange={handleInputChange}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
            <input
              type="date"
              name="deadline"
              placeholder="Deadline"
              value={newProject.deadline}
              onChange={handleInputChange}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white font-medium py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 mt-4"
          >
            Add Project
          </button>
        </form>
      </div>

      <div className="bg-white p-6 shadow-lg rounded-lg">
        <h2 className="text-2xl font-bold mb-4">Projects List</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">Name</th>
                <th className="py-2 px-4 border-b">Status</th>
                <th className="py-2 px-4 border-b">Budget</th>
                <th className="py-2 px-4 border-b">Deadline</th>
                <th className="py-2 px-4 border-b">Actions</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((project) => (
                <tr key={project.id}>
                  <td className="py-2 px-4 border-b">{project.name}</td>
                  <td className="py-2 px-4 border-b">{project.status}</td>
                  <td className="py-2 px-4 border-b">{project.budget}</td>
                  <td className="py-2 px-4 border-b">{project.deadline}</td>
                  <td className="py-2 px-4 border-b">
                    <button
                      onClick={() => handleUpdateProject(project.id, project)}
                      className="bg-yellow-500 text-white py-1 px-2 rounded-md hover:bg-yellow-600 mr-2"
                    >
                      Update
                    </button>
                    <button
                      onClick={() => handleDeleteProject(project.id)}
                      className="bg-red-500 text-white py-1 px-2 rounded-md hover:bg-red-600"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}