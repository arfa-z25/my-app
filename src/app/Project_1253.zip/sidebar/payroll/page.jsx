"use client";
import { useState, useEffect } from "react";
import axios from "axios";

export default function Payroll() {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [salaryDetails, setSalaryDetails] = useState({
    baseSalary: "",
    workingHours: "",
    bonuses: "",
    deductions: "",
  });

  useEffect(() => {
    // Fetch employees from the API
    const fetchEmployees = async () => {
      try {
        const response = await axios.get("/api/employees");
        setEmployees(response.data);
      } catch (error) {
        console.error("Error fetching employees:", error);
      }
    };

    fetchEmployees();
  }, []);

  const handleEmployeeSelect = (employee) => {
    setSelectedEmployee(employee);
    setSalaryDetails({
      baseSalary: employee.baseSalary || "",
      workingHours: employee.workingHours || "",
      bonuses: employee.bonuses || "",
      deductions: employee.deductions || "",
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSalaryDetails((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSave = async () => {
    try {
      const response = await axios.put(`/api/employees/${selectedEmployee.id}/payroll`, salaryDetails);
      alert("Payroll details updated successfully!");
      setSelectedEmployee(null);
      setSalaryDetails({
        baseSalary: "",
        workingHours: "",
        bonuses: "",
        deductions: "",
      });
    } catch (error) {
      console.error("Error updating payroll details:", error);
      alert("Failed to update payroll details.");
    }
  };

  return (
    <div className="container mx-auto p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-6 text-center">Payroll Management</h1>

      <div className="bg-white p-6 shadow-lg rounded-lg mb-6">
        <h2 className="text-2xl font-bold mb-4">Employees</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">Name</th>
                <th className="py-2 px-4 border-b">Role</th>
                <th className="py-2 px-4 border-b">Actions</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((employee) => (
                <tr key={employee.id}>
                  <td className="py-2 px-4 border-b">{employee.name}</td>
                  <td className="py-2 px-4 border-b">{employee.role}</td>
                  <td className="py-2 px-4 border-b">
                    <button
                      onClick={() => handleEmployeeSelect(employee)}
                      className="bg-blue-500 text-white py-1 px-2 rounded-md hover:bg-blue-600"
                    >
                      Manage Payroll
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedEmployee && (
        <div className="bg-white p-6 shadow-lg rounded-lg">
          <h2 className="text-2xl font-bold mb-4">Manage Payroll for {selectedEmployee.name}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="number"
              name="baseSalary"
              placeholder="Base Salary"
              value={salaryDetails.baseSalary}
              onChange={handleInputChange}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
            <input
              type="number"
              name="workingHours"
              placeholder="Working Hours"
              value={salaryDetails.workingHours}
              onChange={handleInputChange}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
            <input
              type="number"
              name="bonuses"
              placeholder="Bonuses"
              value={salaryDetails.bonuses}
              onChange={handleInputChange}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
            />
            <input
              type="number"
              name="deductions"
              placeholder="Deductions"
              value={salaryDetails.deductions}
              onChange={handleInputChange}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <button
            onClick={handleSave}
            className="w-full bg-green-600 text-white font-medium py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 mt-4"
          >
            Save Payroll Details
          </button>
        </div>
      )}
    </div>
  );
}